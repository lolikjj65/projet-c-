#pragma once


using namespace System;

public ref class Orders {
public:
    int OrderID;
    int UserID;
    double TotalPrice;
    
}; 
