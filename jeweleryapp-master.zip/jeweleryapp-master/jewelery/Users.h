#pragma once


using namespace System;

public ref class Users {
public:
	int ID;
	String^ Username;
	String^ Email;
	String^ Password;


};
